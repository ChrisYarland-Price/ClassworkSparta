require 'json'
require_relative '../json_parsing_walkthrough'
# require_relative 'json_example.json'

RSpec.configure do |config|
  config.formatter = :documentation
  config.color = true
end
